dp = [1,2]
print(dp[2])